export const firebaseConfig = {
    fire: {
        apiKey: "AIzaSyDpKul2aEmTl7LBvWy3fCAzisXzetZs_l4",
        authDomain: "proyecto-pps.firebaseapp.com",
        databaseURL: "https://proyecto-pps.firebaseio.com",
        projectId: "proyecto-pps",
        storageBucket: "proyecto-pps.appspot.com",
        messagingSenderId: "829486067560"
    }
};