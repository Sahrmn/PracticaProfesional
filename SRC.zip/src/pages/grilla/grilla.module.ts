import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GrillaPage } from './grilla';

@NgModule({
  declarations: [
    GrillaPage,
  ],
  imports: [
    IonicPageModule.forChild(GrillaPage),
  ],
})
export class GrillaPageModule {}
